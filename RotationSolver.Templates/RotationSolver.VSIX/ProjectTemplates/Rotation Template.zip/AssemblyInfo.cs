﻿//Put your hash into this one if you want someone say hello to you when they are using RotationSolver in Duty with you.
[assembly: AuthorHash(Hash = "Ig4lHXUohMZNIeheUtAtRg==")]

//Something to show your link.
[assembly: AssemblyLink(Donate = "https://ko-fi.com/archited", UserName = "ArchiDog1998", Repository = "FFXIVRotations")]