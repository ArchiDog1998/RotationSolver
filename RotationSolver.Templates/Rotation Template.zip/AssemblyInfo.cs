﻿//Put your hash into this one if you want someone say hello to you when they are using RotationSolver in Duty with you.
[assembly: AuthorHash("$Your Hash in Debug Tab$")]